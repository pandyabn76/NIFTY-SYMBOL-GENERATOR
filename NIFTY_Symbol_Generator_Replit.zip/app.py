
# NIFTY Option Symbols Generator (Replit App)

import streamlit as st
import pandas as pd
import io

def automate_nifty_symbol_generation(uploaded_file, expiry_date, atm_price, strike_range=1000, ltp_min=150, ltp_max=250):
    df_raw = pd.read_csv(uploaded_file)

    df_clean = pd.DataFrame({
        'Strike': df_raw.iloc[1:, 10],
        'Call LTP': df_raw.iloc[1:, 5],
        'Put LTP': df_raw.iloc[1:, 16],
    })

    for col in ['Strike', 'Call LTP', 'Put LTP']:
        df_clean[col] = df_clean[col].replace(',', '', regex=True)
        df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')

    df_clean = df_clean.dropna(subset=['Strike'])

    calls = df_clean[['Strike', 'Call LTP']].rename(columns={'Call LTP': 'LTP'})
    puts = df_clean[['Strike', 'Put LTP']].rename(columns={'Put LTP': 'LTP'})
    calls['Type'] = 'C'
    puts['Type'] = 'P'

    options = pd.concat([calls, puts]).reset_index(drop=True)

    options = options[
        (options['Strike'] >= atm_price - strike_range) &
        (options['Strike'] <= atm_price + strike_range)
    ]

    filtered_options = options[
        (options['LTP'] >= ltp_min) &
        (options['LTP'] <= ltp_max)
    ]

    def format_symbol(row):
        return f"NIFTY{expiry_date}{row['Type']}{int(row['Strike']):05d}"

    filtered_options['Symbol'] = filtered_options.apply(format_symbol, axis=1)

    symbols_text = ",".join(filtered_options['Symbol'].tolist())

    return symbols_text

# ---- Streamlit App ---- #
st.title("🎉 NIFTY Options Symbol Generator")

uploaded_file = st.file_uploader("Upload Option Chain CSV File", type=['csv'])
expiry_date = st.text_input("Enter Expiry Date (YYMMDD)", value="250424")
atm_price = st.number_input("Enter ATM Strike Price", value=24000, step=50)

if st.button("Generate Symbols"):
    if uploaded_file is not None and expiry_date and atm_price:
        with st.spinner('Processing file...'):
            symbols_text = automate_nifty_symbol_generation(uploaded_file, expiry_date, atm_price)

            st.success("Symbols generated successfully!")

            # Allow file download
            st.download_button(
                label="📥 Download Symbol File",
                data=symbols_text,
                file_name=f"NIFTY_filtered_symbols_{expiry_date}.txt",
                mime="text/plain"
            )
    else:
        st.error("Please upload a file and fill all inputs.")

st.markdown("---")
st.caption("Built for faster NIFTY Options processing 🚀")
